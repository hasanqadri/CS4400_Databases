INSERT INTO Data_types (type) VALUES ('mold'), ('air_quality');
