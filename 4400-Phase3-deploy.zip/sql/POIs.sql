INSERT INTO POIs VALUES('Atlanta', 'Georgia', 'Georgia Tech', '2017-01-21 05:21:21', 0, 30332);
INSERT INTO POIs VALUES('Atlanta', 'Georgia', 'GSU', NULL, 0, 30303);
INSERT INTO POIs VALUES('Atlanta', 'Georgia', 'Emory', NULL, 0, 30322);
INSERT INTO POIs VALUES('Chicago', 'Illinois', 'Uchicago','2017-02-24 06:22:22', 1, 60637);
INSERT INTO POIs VALUES('Houston', 'Texas', 'Virginia Tech', NULL, 0, 24061);
INSERT INTO POIs VALUES('Atlanta', 'Georgia', 'Georgia Aquarium', NULL, 0, 30601);
INSERT INTO POIs VALUES('Chicago', 'Illinois', 'Obama Library', NULL, 0, 27517);
INSERT INTO POIs VALUES('Austin', 'Texas', 'UT Austin', NULL, 0, 37011);
INSERT INTO POIs VALUES('Columbus', 'Ohio', 'RNC Convention', NULL, 0, 22901);
INSERT INTO POIs VALUES('New York', 'New York', 'Trump Tower', NULL, 0, 37501);




