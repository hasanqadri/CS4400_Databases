INSERT INTO Users VALUES('fnelson0','jburns0@salon.com','gItnh7','admin');
INSERT INTO Users VALUES('mwest1','kwilliamson1@imdb.com','c124i9ZgOO','scientist');
INSERT INTO Users VALUES('kpowell2','ppierce2@dagondesign.com','O8m2r7dUs8','admin');
INSERT INTO Users VALUES('kgreen3','cmartin3@i2i.jp','BJKcdvPuD','scientist');
INSERT INTO Users VALUES('admin','jcook4@tinyurl.com','admin','admin');
INSERT INTO Users VALUES('jwarren5','afoster5@alexa.com','MaYrc7jvk','scientist');
INSERT INTO Users VALUES('jbarnes6','pphillips6@hugedomains.com','0PcFobpHEtpx','admin');
INSERT INTO Users VALUES('ebrown7','sbryant7@deliciousdays.com','pqiu9wqCiiR','scientist');
INSERT INTO Users VALUES('awilliamson8','dhenderson8@rakuten.co.jp','YZdDzOyJUHa','admin');
INSERT INTO Users VALUES('jking9','scampbell9@skyrock.com','HrOE5aS2','scientist');
INSERT INTO Users VALUES('lhudsona','sstonea@123-reg.co.uk','5wmq5h7gAiGw','admin');
INSERT INTO Users VALUES('jhernandezb','rhansenb@google.it','VDQMGOPzg8','scientist');
INSERT INTO Users VALUES('hmorrisonc','kharperc@dagondesign.com','voW0OV0zjEo','admin');
INSERT INTO Users VALUES('vmorgand','bwatkinsd@weather.com','w536mJmb','scientist');
INSERT INTO Users VALUES('jreede','aalvareze@microsoft.com','y1LFoftD','admin');
INSERT INTO Users VALUES('rcooperf','wmasonf@shareasale.com','OwVvmwlRu','scientist');
INSERT INTO Users VALUES('phuntg','imorenog@cbslocal.com','51A2Su5kRX6Y','admin');
INSERT INTO Users VALUES('pnelsonh','lrobertsonh@statcounter.com','BbA1Za0h','scientist');
INSERT INTO Users VALUES('tsmithi','treyesi@house.gov','2eWq9JBfDaR','admin');
INSERT INTO Users VALUES('rjenkinsj','mbennettj@google.com','nDyBYwyX9C20','scientist');

INSERT INTO Users VALUES('jwilliamson0','bbowman0@imageshack.us','iMNU6BB4Knuj','official');
INSERT INTO Users VALUES('nwatkins1','jthompson1@japanpost.jp','McvsKTuPOsF6','official');
INSERT INTO Users VALUES('pford2','koliver2@google.co.uk','viNOh9','official');
INSERT INTO Users VALUES('apatterson3','rgonzalez3@desdev.cn','DrLBMibbV','official');
INSERT INTO Users VALUES('wlarson4','pwest4@issuu.com','jmdAhAWqRrJY','official');


