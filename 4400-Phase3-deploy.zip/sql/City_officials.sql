INSERT INTO City_officials VALUES('jwilliamson0','Mayor',1,'Atlanta','Georgia');
INSERT INTO City_officials VALUES('nwatkins1','Policeman',0,'Los Angeles','California');
INSERT INTO City_officials VALUES('pford2','Firefighter',1,'Chicago','Illinois');
INSERT INTO City_officials VALUES('apatterson3','General',1,'Houston','Texas');
INSERT INTO City_officials VALUES('wlarson4','Mayor',0,'Philadelphia','Pennsylvania');
