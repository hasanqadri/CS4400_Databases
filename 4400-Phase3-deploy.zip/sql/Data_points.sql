INSERT INTO Data_points VALUES('Georgia Tech', '2017-01-31 15:32:00', 12, 'mold', 0);
INSERT INTO Data_points VALUES('Georgia Tech', '2017-02-15 16:21:11', 42, 'mold', 0);
INSERT INTO Data_points VALUES('Georgia Tech', '2017-02-24 4:29:00', 4, 'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech', '2017-01-02 03:57:01', 34, 'air_quality',0);

INSERT INTO Data_points VALUES('Uchicago','2017-03-07 05:21:01',31,'mold',0);
INSERT INTO Data_points VALUES('Uchicago','2017-03-12 04:26:22',24,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-02-13 04:43:00',34,'air_quality',0);
INSERT INTO Data_points VALUES('GSU','2017-01-31 01:33:00', 9,'air_quality',0);


INSERT INTO Data_points VALUES('Emory','2017-01-17 03:33:00',19,'mold',0);
INSERT INTO Data_points VALUES('Emory','2017-01-21 02:56:00', 22, 'air_quality',0);
INSERT INTO Data_points VALUES('Emory','2017-02-07 05:44:01', 32,'air_quality',0);
INSERT INTO Data_points VALUES('Emory','2017-02-20 03:04:11',51, 'air_quality',0);
INSERT INTO Data_points VALUES('Uchicago','2017-03-15 05:55:00',43,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-01-28 02:05:33',15,'air_quality',0);
INSERT INTO Data_points VALUES('Emory','2017-02-03 01:59:00',22,'mold',0);
INSERT INTO Data_points VALUES('Uchicago','2017-03-24 03:32:00',20,'mold',0);
INSERT INTO Data_points VALUES('GSU','2017-03-01 02:28:00',33,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-03-19 01:02:00',40,'air_quality',0);
INSERT INTO Data_points VALUES('Uchicago','2017-02-06 05:13:04',8,'mold',0);
INSERT INTO Data_points VALUES('Emory','2017-01-31 02:45:03',44,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-03-10 02:11:00',31,'mold',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-01-09 04:05:31',36,'mold',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-01-10 03:33:04',15,'air_quality',0);

INSERT INTO Data_points VALUES('Emory','2017-02-18 05:53:00',17,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-01-11 05:43:02',41,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-02-25 03:22:21',4,'mold',0);
INSERT INTO Data_points VALUES('Emory','2017-01-18 01:54:30',42,'air_quality',0);
INSERT INTO Data_points VALUES('Emory','2017-03-20 05:58:09',13,'air_quality',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-03-23 03:02:01',20,'mold',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-03-16 02:29:10',23,'mold',0);
INSERT INTO Data_points VALUES('Uchicago','2017-02-23 11:32:02',43,'air_quality',0);
INSERT INTO Data_points VALUES('GSU','2017-03-24 13:32:02',35,'mold',0);
INSERT INTO Data_points VALUES('Uchicago','2017-03-06 12:35:22',9,'mold',0);
INSERT INTO Data_points VALUES('GSU','2017-02-21 11:26:32',29,'mold',0);
INSERT INTO Data_points VALUES('Georgia Tech','2017-03-19 14:44:23',42,'mold',0);
INSERT INTO Data_points VALUES('Emory','2017-02-05 15:38:42',48,'mold',0);
INSERT INTO Data_points VALUES('GSU','2017-02-08 02:33:22',4,'air_quality',0);
INSERT INTO Data_points VALUES('GSU','2017-02-11 14:32:33',27,'mold',0);
INSERT INTO Data_points VALUES('GSU','2017-01-08 16:54:54',24,'mold',0);